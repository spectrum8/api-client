<?php
namespace Spectrum8\Exception;

/**
 * Class SpectrumException
 * @package Spectrum8\Exception
 */
class SpectrumException extends \Exception
{

}
